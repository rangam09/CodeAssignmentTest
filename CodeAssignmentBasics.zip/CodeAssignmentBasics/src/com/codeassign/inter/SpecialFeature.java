package com.codeassign.inter;

public interface SpecialFeature {
	public void sound();
	//public void swim();
}
