package com.codeassign.main;

import com.codeassign.vo.Bird;
import com.codeassign.vo.Duck;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class Solution {
	public static void main(String args[]) {
		Bird bird = new Duck();
		bird.walk();
		bird.fly();
		bird.sing();
	}
}

/*class Animal {
	public void walk() {
		System.out.println("I am walking");
	 
	}
}

class Bird extends Animal{
	void fly() {
		System.out.println("I am flying");
	 
	}
	void sing() {
		System.out.println("I am singing");
	 
	}
}*/