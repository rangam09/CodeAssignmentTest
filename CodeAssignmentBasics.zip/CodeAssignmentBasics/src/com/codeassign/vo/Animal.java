package com.codeassign.vo;

import com.codeassign.inter.SpecialFeature;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public abstract class Animal implements SpecialFeature{
	static Type type;
	public Animal(Type type) {
		if(type == null) {
			this.type = new Type();
			this.type.setCanWalk(true);
		} else {
			setType(type);
		}
	}
	/**
	 * 
	 */
	public void walk() {
		System.out.println("I am walking");
		
		
	}
	
	
	
	public Type getType() {
		return type;
	}
	public void setType(Type type) {
		this.type = type;
	}
	
	
}
