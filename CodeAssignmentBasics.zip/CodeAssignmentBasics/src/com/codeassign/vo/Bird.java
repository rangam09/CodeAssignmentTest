package com.codeassign.vo;

import com.codeassign.inter.SpecialFeature;
/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class Bird extends Animal implements SpecialFeature {
	
	
	public Bird() {
		super(type);
		if(type == null) {
			type = new Type();
			type.setCanFly(true);
			type.setCanSing(true);
			
		} else {
			type.setCanFly(true);
			type.setCanSing(true);
		}
		
		
	}
		

	public void fly() {
		System.out.println("I am flying");
	}
	
	public void sing() {
		System.out.println("I am singing");
		
	}
	
	public void swim() {
		
	}
	@Override
	public void sound() {
		// TODO Auto-generated method stub
		
	}
	
}
