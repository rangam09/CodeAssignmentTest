package com.codeassign.vo;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class ButterFly extends Caterpiller{
	public ButterFly() {
		super();
		if(type == null) {
			type = new Type();
			type.setCanFly(true);
			
		} else {
			type.setCanFly(true);
			
		}
	}
	@Override
	public void fly() {
		System.out.println("A butterfly can fly");
		
	}

	@Override
	public void sound() {
		System.out.println("A butterfly cannot make sound");
		
	}

	@Override
	public void swim() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sing() {
		// TODO Auto-generated method stub
		
	}
	
}
