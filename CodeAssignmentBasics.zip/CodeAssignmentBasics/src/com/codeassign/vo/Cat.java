package com.codeassign.vo;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class Cat extends Animal {
	public Cat() {
		super(type);
		if(type == null) {
			type = new Type();
			
			
		} else {
			
			
		}
	}
	@Override
	public void sound() {
		System.out.println("Meow");
		
	}
		
}
