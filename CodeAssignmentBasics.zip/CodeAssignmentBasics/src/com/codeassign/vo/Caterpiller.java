package com.codeassign.vo;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class Caterpiller extends Bird{
	
	@Override
	public void fly() {
		System.out.println("A caterpiller cannot fly");
	}
	public void walk() {
		System.out.println("A caterpiller can walk(crawl)");
	}
}
