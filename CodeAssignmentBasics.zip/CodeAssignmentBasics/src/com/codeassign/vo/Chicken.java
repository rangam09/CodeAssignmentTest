package com.codeassign.vo;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class Chicken extends Bird {
		
	public Chicken() {
		super();
		if(type == null) {
			type = new Type();
			type.setCanFly(false);
			
		} else {
			type.setCanFly(false);
			
		}
	}
	@Override
	public void sound() {
		System.out.println("Cluck, cluck");
		
	}

	@Override
	public void fly() {
		System.out.println("A chicken cannot fly");
		
	}

	@Override
	public void swim() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sing() {
		// TODO Auto-generated method stub
		
	}
	
}
