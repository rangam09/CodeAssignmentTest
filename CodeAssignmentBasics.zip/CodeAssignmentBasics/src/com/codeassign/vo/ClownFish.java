package com.codeassign.vo;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class ClownFish extends Fish{

	
	public void size() {
		System.out.println("A clownFish is small");
		
	}

	
	public void color() {
		System.out.println("A clownFish is colourful(orange)");
		
	}
	
	public void jokes() {
		System.out.println("A clownFish makes jokes");
		
	}

	
	
}
