package com.codeassign.vo;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class Dog extends Animal {
	public Dog() {
		super(type);
		if(type == null) {
			type = new Type();
			type.setCanSwim(true);
			
		} else {
			type.setCanSwim(true);
			
		}
	}
	@Override
	public void sound() {
		System.out.println("Woof, woof");
		
	}
		
}
