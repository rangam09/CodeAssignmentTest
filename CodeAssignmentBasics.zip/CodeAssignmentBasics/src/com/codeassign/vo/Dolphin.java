package com.codeassign.vo;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class Dolphin extends Bird {

	public Dolphin() {
		super();
		if(type == null) {
			type = new Type();
			type.setCanSwim(true);
			
		} else {
			type.setCanSwim(true);
			
		}
	}
	@Override
	public void swim() {
		System.out.println("A dolphin can swim");
		
	}
		
}
