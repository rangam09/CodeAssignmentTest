package com.codeassign.vo;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class Duck extends Bird {
	
	public Duck() {
		super();
		if(type == null) {
			type = new Type();
			type.setCanSwim(true);
			
		} else {
			type.setCanSwim(true);
			
		}
	}
	@Override
	public void sound() {
		System.out.println("Quack, quack");
		
	}

	@Override
	public void swim() {
		System.out.println("A duck can swim");
		
	}

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sing() {
		// TODO Auto-generated method stub
		
	}
	
}
