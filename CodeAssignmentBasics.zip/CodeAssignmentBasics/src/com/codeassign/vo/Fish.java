package com.codeassign.vo;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class Fish extends Bird {

	public Fish() {
		super();
		if(type == null) {
			type = new Type();
			type.setCanSwim(true);
			type.setCanWalk(false);
			type.setCanSing(false);
		} else {
			type.setCanSwim(true);
			type.setCanWalk(false);
			type.setCanSing(false);
		}
	}
	@Override
	public void swim() {
		System.out.println("A fish can swim");
		
	}

	public void walk() {
		System.out.println("A fish don't walk");
		
	}
	
	public void sing() {
		System.out.println("A fish don't sing");
		
	}
		
}
