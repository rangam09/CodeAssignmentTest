package com.codeassign.vo;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class Parrot extends Bird {
	String living="";
	
	public Parrot() {
		super();
		if(type == null) {
			type = new Type();
			type.setCanFly(true);
			type.setCanSing(true);
		} else {
			type.setCanFly(true);
			type.setCanSing(true);
		}
	}
	public Parrot(String living){
		this.living = living;
	}
	
	@Override
	public void fly() {
		System.out.println("I am flying");
		
	}
	
	@Override
	public void sound() {
		
		if("dogs".equalsIgnoreCase(living)) {
			Dog dog = new Dog();
			dog.sound();
		} else if("cats".equalsIgnoreCase(living)) {
			Cat cat = new Cat();
			cat.sound();
		} else if("rooster".equalsIgnoreCase(living)) {
			Rooster rooster = new Rooster();
			rooster.sound();
		} else if("duck".equalsIgnoreCase(living)) {
			Duck duck = new Duck();
			duck.sound();
		} else if("phone".equalsIgnoreCase(living)) {
			Phone phone = new Phone();
			phone.sound();
		}
	}
	@Override
	public void swim() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void sing() {
		System.out.println("I am singing");
		
	}

	
}
