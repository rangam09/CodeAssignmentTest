package com.codeassign.vo;

import com.codeassign.inter.SpecialFeature;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class Phone implements SpecialFeature{
	

	@Override
	public void sound() {
		System.out.println("Tring, tring");
	}
	
}
