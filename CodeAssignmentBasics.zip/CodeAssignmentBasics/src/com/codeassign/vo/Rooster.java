package com.codeassign.vo;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class Rooster extends Chicken {
		
	public Rooster() {
		super();
		if(type == null) {
			type = new Type();
			//type.setCanFly(false);
			
		} else {
			//type.setCanFly(false);
			
		}
	}
	@Override
	public void sound() {
		System.out.println("Cock-a-doodle-doo");
		
	}

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void swim() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sing() {
		// TODO Auto-generated method stub
		
	}

}
