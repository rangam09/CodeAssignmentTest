package com.codeassign.vo;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class Shark extends Fish{

	
	
	public void size() {
		System.out.println("A shark is large");
		
	}

	
	public void color() {
		System.out.println("A shark is grey");
		
	}
	
	public void eat() {
		System.out.println("A shark eat other fish");
		
	}

	
}
