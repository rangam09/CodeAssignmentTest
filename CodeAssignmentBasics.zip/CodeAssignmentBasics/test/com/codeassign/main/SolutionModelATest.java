package com.codeassign.main;

import com.codeassign.vo.Bird;
import com.codeassign.vo.Chicken;
import com.codeassign.vo.ClownFish;
import com.codeassign.vo.Dog;
import com.codeassign.vo.Dolphin;
import com.codeassign.vo.Duck;
import com.codeassign.vo.Fish;
import com.codeassign.vo.Parrot;
import com.codeassign.vo.Rooster;
import com.codeassign.vo.Shark;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class SolutionModelATest extends TestCase 
{

	public SolutionModelATest( String testName )
    {
        super( testName );
    }
	
	public static Test suite()
    {
        return new TestSuite( SolutionModelATest.class );
    }
	
	//@Test
	public void testCaseBird1() {
		
		System.out.println("Bird......");
		System.out.println("-----------------------------------------");
		Bird bird = new Bird();
		bird.walk();
		bird.fly();
		bird.sing();
		//fail("Not yet implemented");
	}
	
	public void testCaseDuckChicken2() {
		Bird bird = new Duck();
		
		System.out.println("Duck......");
		System.out.println("-----------------------------------------");
		bird.sound();
		bird.swim();
		
		System.out.println("Chicken......");
		System.out.println("-----------------------------------------");
		bird = new Chicken();
		bird.sound();
		bird.fly();
	}
	
	public void testCaseRooster3() {
		Rooster rooster = new Rooster();
		System.out.println("Rooster......");
		System.out.println("-----------------------------------------");
		//rooster.walk();
		rooster.sound();
	}
	
	public void testCaseParrot4() {
		Parrot parrot = new Parrot("dogs");
		System.out.println("-----------------------------------------");
		System.out.println("Parrot living with dogs......");
		System.out.println("-----------------------------------------");
		parrot.sound();
		parrot = new Parrot("cats");
		System.out.println("-----------------------------------------");
		System.out.println("Parrot living with cats......");
		System.out.println("-----------------------------------------");
		parrot.sound();
		parrot = new Parrot("rooster");
		System.out.println("-----------------------------------------");
		System.out.println("Parrot living with rooster......");
		System.out.println("-----------------------------------------");
		parrot.sound();
		parrot = new Parrot("duck");
		System.out.println("-----------------------------------------");
		System.out.println("Parrot living with duck......");
		System.out.println("-----------------------------------------");
		parrot.sound();
		parrot = new Parrot("phone");
		System.out.println("-----------------------------------------");
		System.out.println("Parrot living with phone......");
		System.out.println("-----------------------------------------");
		parrot.sound();
	}
	
}
