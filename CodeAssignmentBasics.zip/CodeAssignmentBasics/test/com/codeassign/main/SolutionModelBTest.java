package com.codeassign.main;

import com.codeassign.vo.ClownFish;
import com.codeassign.vo.Dolphin;
import com.codeassign.vo.Fish;
import com.codeassign.vo.Shark;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class SolutionModelBTest extends TestCase 
{

	public SolutionModelBTest( String testName )
    {
        super( testName );
    }
	
	public static Test suite()
    {
        return new TestSuite( SolutionModelBTest.class );
    }
	
	
	public void testCaseFish5() {
		Fish fish = new Fish();
		System.out.println("Fish......");
		System.out.println("-----------------------------------------");
		fish.sing();
		fish.walk();
		fish.swim();
		System.out.println("-----------------------------------------");
	}
	public void testCaseSharkClownFish6() {
		Shark shark = new Shark();
		System.out.println("Shark......");
		System.out.println("-----------------------------------------");
		shark.size();
		shark.color();
		shark.eat();
		System.out.println("-----------------------------------------");
		ClownFish clownFish = new ClownFish();
		System.out.println("ClownFish......");
		System.out.println("-----------------------------------------");
		clownFish.size();
		clownFish.color();
		clownFish.jokes();
		System.out.println("-----------------------------------------");
	}
	
	public void testCaseDolphin7() {
		Dolphin dolphin = new Dolphin();
		System.out.println("Dolphin......");
		System.out.println("-----------------------------------------");
		dolphin.swim();
		
		System.out.println("-----------------------------------------");
		
	}
}
