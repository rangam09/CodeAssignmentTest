package com.codeassign.main;

import com.codeassign.vo.ButterFly;
import com.codeassign.vo.Caterpiller;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class SolutionModelDTest extends TestCase 
{

	public SolutionModelDTest( String testName )
    {
        super( testName );
    }
	
	public static Test suite()
    {
        return new TestSuite( SolutionModelDTest.class );
    }
	
	//@Test
	public void testCaseButterfly8() {
		
		System.out.println("ButterFly......");
		System.out.println("-----------------------------------------");
		ButterFly butterFly = new ButterFly();
		
		butterFly.fly();
		butterFly.sound();
		System.out.println("-----------------------------------------");
	}
	public void testCaseButterfly9() {
		
		System.out.println("ButterFly......");
		System.out.println("-----------------------------------------");
		Caterpiller caterpiller = new Caterpiller();
		
		caterpiller.fly();
		caterpiller.walk();
		System.out.println("-----------------------------------------");
	}
	
}
