package com.codeassign.main;

import com.codeassign.vo.Animal;
import com.codeassign.vo.Bird;
import com.codeassign.vo.ButterFly;
import com.codeassign.vo.Cat;
import com.codeassign.vo.Caterpiller;
import com.codeassign.vo.Chicken;
import com.codeassign.vo.ClownFish;
import com.codeassign.vo.Dog;
import com.codeassign.vo.Dolphin;
import com.codeassign.vo.Duck;
import com.codeassign.vo.Fish;
import com.codeassign.vo.Parrot;
import com.codeassign.vo.Rooster;
import com.codeassign.vo.Shark;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * @author srangam
 * @date Mar 24, 2019
 * @version 1.0
 *
 */
public class SolutionModelETest extends TestCase 
{

	public SolutionModelETest( String testName )
    {
        super( testName );
    }
	
	public static Test suite()
    {
        return new TestSuite( SolutionModelETest.class );
    }
	
	//@Test
	public void testCaseButterfly10() {
		
		Animal[] animals = new Animal[] {
			new Bird(),
			new Duck(),
			new Chicken(),
			new Rooster(),
			new Parrot(),
			new Fish(),
			new Shark(),
			new ClownFish(),
			new Dolphin(),
			//new Frog(),
			new Dog(),
			new ButterFly(),
			new Cat()
		};
		
		int flyCount=0;
		int walkCount=0;
		int singCount=0;
		int swimCount=0;
		
		for(Animal animal : animals) {
			System.out.println("isCanFly Animals......"+animal.getType().isCanFly());
			System.out.println("isCanWalk Animals......"+animal.getType().isCanWalk());
			System.out.println("isCanSing Animals......"+animal.getType().isCanSing());
			System.out.println("isCanSwim Animals......"+animal.getType().isCanSwim());
			
			if(animal instanceof Bird) {
				flyCount++;
				singCount++;
			} else if(animal instanceof Duck) {
				swimCount++;
			} else if(animal instanceof Chicken) {
				
			} else if(animal instanceof Rooster) {
				
			} else if(animal instanceof Parrot) {
				flyCount++;
				singCount++;
			} else if(animal instanceof Fish) {
				swimCount++;
			} else if(animal instanceof Shark) {
				
			} else if(animal instanceof ClownFish) {
				
			} else if(animal instanceof Dolphin) {
				swimCount++;
			} else if(animal instanceof Dog) {
				swimCount++;
			} else if(animal instanceof ButterFly) {
				flyCount++;
			} else if(animal instanceof Cat) {
				
			}
			/*if(animal.getType().isCanFly()) {
				flyCount++;
			} else if(animal.getType().isCanWalk()) {
				walkCount++;
			} else if(animal.getType().isCanSing()) {
				singCount++;
			} else if(animal.getType().isCanSwim()) {
				swimCount++;
			}*/
		}
		
		System.out.println("Counting Animals......");
		System.out.println("-----------------------------------------");
		System.out.println("Number Of Animals that can fly : "+flyCount);
		System.out.println("Number Of Animals that can walk : "+walkCount);
		System.out.println("Number Of Animals that can sing : "+singCount);
		System.out.println("Number Of Animals that can swim : "+swimCount);
		System.out.println("-----------------------------------------");
	}
	
	
}
